Geppetto Jupyter Notebook Extension
===================================

Experimental Jupyter notebook extension. This
extension extends Jupyter Python server based on tornado that allows the
client to establish a websocket connection and server static resources
but there is no real functionality beyond that.

Installation
============

.. code-block:: bash

    pip install jupyter_geppetto
    jupyter nbextension enable --py --sys-prefix jupyter_geppetto

For further information please visit: https://github.com/openworm/org.geppetto.frontend.jupyter


